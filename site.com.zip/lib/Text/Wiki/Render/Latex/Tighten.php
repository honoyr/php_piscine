<?php
class Text_Wiki_Render_Latex_Tighten extends Text_Wiki_Render {
    
    function token()
    {
        return '';
    }
}
?>