<?php

class Text_Wiki_Render_Plain extends Text_Wiki_Render {
    
    function pre()
    {
        return;
    }
    
    function post()
    {
        return;
    }
    
}
?>