<?php

/**
 * dbErrorHandler
 *
 * @param string $message Error message
 * @param string $info Info
 */
function dbErrorHandler($message, $info)
{
    // Если использовалась @, ничего не делать.
    if (!error_reporting()) return;
    // Выводим подробную информацию об ошибке.
    echo "SQL Error: $message<br><pre>"; 
    print_r($info);
    echo "</pre>";
    exit();
}