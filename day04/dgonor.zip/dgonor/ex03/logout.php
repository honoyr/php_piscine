<?php
    session_start();
    $_SESSION['authorization_ur'] = NULL;
?>